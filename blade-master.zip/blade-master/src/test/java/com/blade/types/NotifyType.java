package com.blade.types;

import lombok.Data;

/**
 * @author biezhi
 * @date 2017/9/19
 */
@Data
public class NotifyType {

    private String money;
    private String oid;
}
