package com.blade.ioc;

/**
 * @author biezhi
 * @date 2017/9/18
 */
public class IocTest {
}
