package com.blade.kit.json;

/**
 * Mapping Type
 *
 * @author biezhi
 * @date 2017/9/12
 */
public enum MappingType {

    DATE_PATTEN, BIGDECIMAL_KEEP

}
