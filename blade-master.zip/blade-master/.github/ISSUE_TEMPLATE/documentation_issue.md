---
name: 📚 Documentation Issue
about: For documentation issues, open a pull request at https://github.com/lets-blade/lets-blade.github.io

---

The blade documentation has its own dedicated repository. Please open a pull request at https://github.com/lets-blade/lets-blade.github.io to correct the issue you have found.

Thanks!