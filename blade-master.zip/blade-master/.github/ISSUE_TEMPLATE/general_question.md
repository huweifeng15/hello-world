---
name: 🍻 General Question
about: Template for asking question

---

Please provide the following information if applicable:

- Operating system and its version
- Build tools (e.g. maven or gradle)
- JDK version and blade version(e.g `2.0.8-R1`)
